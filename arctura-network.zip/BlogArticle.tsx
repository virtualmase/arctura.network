import { useParams, Link } from "wouter";
import { Calendar, Clock, ArrowLeft, Share2 } from "lucide-react";
import { getArticleBySlug, getRelatedArticles, BlogArticle } from "@/lib/blog-data";
import { Button } from "@/components/ui/button";
import { useEffect } from "react";

const displayFontStyle = { fontFamily: "'Syne', sans-serif" };
const monoFontStyle = { fontFamily: "'IBM Plex Mono', monospace" };

export default function BlogArticle() {
  const params = useParams();
  const slug = params.slug as string;
  const article = getArticleBySlug(slug);
  const relatedArticles = article ? getRelatedArticles(article.id, 3) : [];

  // Update page title and meta tags
  useEffect(() => {
    if (article) {
      document.title = `${article.title} | Arctura.network Blog`;
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) {
        metaDescription.setAttribute("content", article.seoDescription);
      }
    }
  }, [article]);

  if (!article) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        {/* Navigation */}
        <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
          <div className="container flex items-center justify-between h-16">
            <Link href="/">
              <a className="font-bold text-xl text-primary" style={displayFontStyle}>
                Arctura.network
              </a>
            </Link>
          </div>
        </nav>

        <div className="pt-32 pb-16 text-center">
          <h1 className="text-4xl font-bold mb-4" style={displayFontStyle}>
            Article Not Found
          </h1>
          <p className="text-muted-foreground mb-8">
            The article you're looking for doesn't exist.
          </p>
          <Link href="/blog">
            <a>
              <Button>Back to Blog</Button>
            </a>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <Link href="/">
            <a className="font-bold text-xl text-primary" style={displayFontStyle}>
              Arctura.network
            </a>
          </Link>
          <div className="flex items-center gap-6">
            <Link href="/">
              <a className="text-sm hover:text-primary transition">Home</a>
            </Link>
            <Link href="/blog">
              <a className="text-sm hover:text-primary transition">Blog</a>
            </Link>
            <Button variant="outline" size="sm">
              Join Discord
            </Button>
          </div>
        </div>
      </nav>

      {/* Article Header */}
      <article className="pt-32 pb-16 border-b border-border">
        <div className="container max-w-3xl">
          {/* Back Button */}
          <Link href="/blog">
            <a className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition mb-8">
              <ArrowLeft className="w-4 h-4" />
              Back to Blog
            </a>
          </Link>

          {/* Title */}
          <h1 className="font-bold text-5xl mb-6 leading-tight" style={displayFontStyle}>
            {article.title}
          </h1>

          {/* Metadata */}
          <div className="flex flex-wrap gap-6 text-sm text-muted-foreground mb-8 pb-8 border-b border-border">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {new Date(article.publishedAt).toLocaleDateString("en-US", {
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              {article.readingTime} min read
            </div>
            <div className="text-xs bg-primary/10 text-primary px-3 py-1 rounded-full">
              {article.category}
            </div>
            <div className="flex items-center gap-2">
              By <span className="font-medium">{article.author}</span>
            </div>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-8">
            {article.tags.map((tag) => (
              <Link key={tag} href={`/blog?tag=${tag}`}>
                <a className="text-xs px-3 py-1 rounded-full bg-border hover:bg-primary/20 transition">
                  {tag}
                </a>
              </Link>
            ))}
          </div>

          {/* Share Buttons */}
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Share:</span>
            <button
              onClick={() => {
                const url = window.location.href;
                navigator.clipboard.writeText(url);
              }}
              className="p-2 rounded-lg bg-card border border-border hover:border-primary/50 transition"
              title="Copy link"
            >
              <Share2 className="w-4 h-4" />
            </button>
            <a
              href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(article.title)}&url=${encodeURIComponent(window.location.href)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm px-4 py-2 rounded-lg bg-card border border-border hover:border-primary/50 transition"
            >
              Twitter
            </a>
          </div>
        </div>
      </article>

      {/* Article Content */}
      <section className="py-16">
        <div className="container max-w-3xl prose prose-invert">
          <div
            className="prose prose-invert max-w-none"
            style={{
              "--tw-prose-body": "var(--foreground)",
              "--tw-prose-headings": "var(--foreground)",
              "--tw-prose-links": "var(--primary)",
              "--tw-prose-code": "var(--primary)",
              "--tw-prose-pre-bg": "var(--card)",
              "--tw-prose-pre-code": "var(--foreground)",
            } as React.CSSProperties}
          >
            {/* Render markdown-like content */}
            {article.content.split("\n\n").map((paragraph, idx) => {
              if (paragraph.startsWith("# ")) {
                return (
                  <h1
                    key={idx}
                    className="font-bold text-4xl mt-8 mb-4"
                    style={displayFontStyle}
                  >
                    {paragraph.slice(2)}
                  </h1>
                );
              } else if (paragraph.startsWith("## ")) {
                return (
                  <h2
                    key={idx}
                    className="font-bold text-3xl mt-8 mb-4"
                    style={displayFontStyle}
                  >
                    {paragraph.slice(3)}
                  </h2>
                );
              } else if (paragraph.startsWith("### ")) {
                return (
                  <h3
                    key={idx}
                    className="font-bold text-2xl mt-6 mb-3"
                    style={displayFontStyle}
                  >
                    {paragraph.slice(4)}
                  </h3>
                );
              } else if (paragraph.startsWith("| ")) {
                // Simple table rendering
                const lines = paragraph.split("\n");
                const headers = lines[0].split("|").map((h) => h.trim());
                const rows = lines.slice(2).map((line) =>
                  line
                    .split("|")
                    .map((cell) => cell.trim())
                    .filter((cell) => cell)
                );

                return (
                  <div key={idx} className="overflow-x-auto my-6">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="border-b border-border">
                          {headers.map((header, i) => (
                            <th
                              key={i}
                              className="text-left px-4 py-2 font-semibold text-primary"
                            >
                              {header}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {rows.map((row, i) => (
                          <tr key={i} className="border-b border-border hover:bg-card/50">
                            {row.map((cell, j) => (
                              <td key={j} className="px-4 py-2 text-muted-foreground">
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                );
              } else if (paragraph.startsWith("> ")) {
                return (
                  <blockquote
                    key={idx}
                    className="border-l-4 border-primary pl-4 py-2 my-6 italic text-muted-foreground"
                  >
                    {paragraph.slice(2)}
                  </blockquote>
                );
              } else if (paragraph.startsWith("```")) {
                const code = paragraph.slice(3, -3).trim();
                return (
                  <pre
                    key={idx}
                    className="bg-card border border-border rounded-lg p-4 my-6 overflow-x-auto"
                    style={monoFontStyle}
                  >
                    <code className="text-sm">{code}</code>
                  </pre>
                );
              } else if (paragraph.startsWith("- ")) {
                const items = paragraph.split("\n").filter((line) => line.startsWith("- "));
                return (
                  <ul key={idx} className="list-disc list-inside my-4 space-y-2">
                    {items.map((item, i) => (
                      <li key={i} className="text-muted-foreground">
                        {item.slice(2)}
                      </li>
                    ))}
                  </ul>
                );
              } else {
                return (
                  <p key={idx} className="text-muted-foreground leading-relaxed my-4">
                    {paragraph}
                  </p>
                );
              }
            })}
          </div>
        </div>
      </section>

      {/* Related Articles */}
      {relatedArticles.length > 0 && (
        <section className="py-16 border-t border-border bg-card/30">
          <div className="container max-w-4xl">
            <h2 className="font-bold text-3xl mb-8" style={displayFontStyle}>
              Related Articles
            </h2>

            <div className="grid md:grid-cols-3 gap-6">
              {relatedArticles.map((relatedArticle: BlogArticle) => (
                <Link key={relatedArticle.id} href={`/blog/${relatedArticle.slug}`}>
                  <div className="group p-6 rounded-lg border border-border hover:border-primary/50 transition bg-card/50 hover:bg-card/80 cursor-pointer">
                    <h3
                      className="font-bold text-lg mb-2 group-hover:text-primary transition line-clamp-2"
                      style={displayFontStyle}
                    >
                      {relatedArticle.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                      {relatedArticle.excerpt}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="w-3 h-3" />
                      {relatedArticle.readingTime} min read
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-16 border-t border-border">
        <div className="container max-w-2xl text-center">
          <h2 className="font-bold text-3xl mb-4" style={displayFontStyle}>
            Ready to Build the Future?
          </h2>
          <p className="text-muted-foreground mb-8">
            Join our community and start building trustworthy autonomous agents.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/">
              <a>
                <Button size="lg">Back to Home</Button>
              </a>
            </Link>
            <Link href="/blog">
              <a>
                <Button size="lg" variant="outline">
                  More Articles
                </Button>
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border bg-card/30">
        <div className="container">
          <div className="flex flex-col sm:flex-row items-center justify-between">
            <div className="font-bold text-primary" style={displayFontStyle}>
              Arctura.network
            </div>
            <div className="flex gap-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-primary transition">
                Privacy
              </a>
              <a href="#" className="hover:text-primary transition">
                Terms
              </a>
              <a href="#" className="hover:text-primary transition">
                Contact
              </a>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-border text-center text-xs text-muted-foreground">
            <p>© 2026 Arctura Collective. Building the future of autonomous intelligence.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
