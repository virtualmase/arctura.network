/**
 * Application Constants
 * 
 * Centralized location for all constant values used throughout the application.
 * This ensures consistency and makes it easier to update values globally.
 */

/**
 * Blog Categories
 * These are the valid categories for blog articles
 */
export const BLOG_CATEGORIES = {
  TECHNICAL: "Technical",
  DESIGN: "Design",
  SUSTAINABILITY: "Sustainability",
  RESEARCH: "Research",
} as const;

export type BlogCategory = typeof BLOG_CATEGORIES[keyof typeof BLOG_CATEGORIES];

/**
 * Blog Tags
 * Common tags used across articles
 */
export const BLOG_TAGS = {
  MANDATE_CHAINS: "Mandate Chains",
  CONSENSUS: "Consensus",
  BYZANTINE_FAULT_TOLERANCE: "Byzantine Fault Tolerance",
  AGENT_NETWORKS: "Agent Networks",
  PROTOCOL_DESIGN: "Protocol Design",
  CRYPTOGRAPHY: "Cryptography",
  AUTHORITY_DELEGATION: "Authority Delegation",
  AGENT_ARCHITECTURE: "Agent Architecture",
  CARBON_AWARENESS: "Carbon Awareness",
  SUSTAINABILITY: "Sustainability",
  GRID_INTEGRATION: "Grid Integration",
  AGENT_OPTIMIZATION: "Agent Optimization",
  AGENT_DESIGN: "Agent Design",
  TRUSTWORTHINESS: "Trustworthiness",
  AUDITABILITY: "Auditability",
  BEST_PRACTICES: "Best Practices",
} as const;

export type BlogTag = typeof BLOG_TAGS[keyof typeof BLOG_TAGS];

/**
 * Navigation Links
 */
export const NAV_LINKS = {
  HOME: "/",
  BLOG: "/blog",
  FEATURES: "#features",
  FAQ: "#faq",
} as const;

/**
 * External Links
 */
export const EXTERNAL_LINKS = {
  DISCORD: "https://discord.gg/arctura",
  TWITTER: "https://twitter.com/arctura",
  GITHUB: "https://github.com/arctura",
  WHITEPAPER: "https://whitepaper.arctura.network",
} as const;

/**
 * Site Metadata
 */
export const SITE_METADATA = {
  NAME: "Arctura.network",
  DESCRIPTION:
    "Autonomous Resource Management for Decentralized AI. Coordinate verifiable agent action across Earth-bound nodes with Resonance BFT consensus and carbon-aware scheduling.",
  URL: "https://arctura.network",
  AUTHOR: "Arctura Collective",
  KEYWORDS: [
    "Arctura",
    "autonomous agents",
    "decentralized AI",
    "blockchain",
    "consensus",
    "mandate chains",
    "carbon-aware",
  ],
} as const;

/**
 * Reading Time Constants
 */
export const READING_TIME = {
  WORDS_PER_MINUTE: 200,
  MIN_READING_TIME: 1,
} as const;

/**
 * Pagination
 */
export const PAGINATION = {
  ARTICLES_PER_PAGE: 10,
  RELATED_ARTICLES_COUNT: 3,
  FEATURED_ARTICLES_COUNT: 3,
} as const;

/**
 * Animations
 */
export const ANIMATIONS = {
  TRANSITION_FAST: "150ms",
  TRANSITION_NORMAL: "300ms",
  TRANSITION_SLOW: "500ms",
} as const;

/**
 * Helper function to validate category
 */
export function isValidCategory(category: string): category is BlogCategory {
  return Object.values(BLOG_CATEGORIES).includes(category as BlogCategory);
}

/**
 * Helper function to validate tag
 */
export function isValidTag(tag: string): tag is BlogTag {
  return Object.values(BLOG_TAGS).includes(tag as BlogTag);
}
