import { Link } from "wouter";
import { Button } from "@/components/ui/button";

interface NavigationProps {
  currentPage?: "home" | "blog" | "article";
}

const displayFontStyle = { fontFamily: "'Syne', sans-serif" };

export function Navigation({ currentPage }: NavigationProps) {
  return (
    <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container flex items-center justify-between h-16">
        <Link href="/">
          <a className="font-bold text-xl text-primary" style={displayFontStyle}>
            Arctura.network
          </a>
        </Link>
        <div className="flex items-center gap-6">
          <Link href="/">
            <a
              className={`text-sm transition ${
                currentPage === "home" ? "text-primary font-semibold" : "hover:text-primary"
              }`}
            >
              Home
            </a>
          </Link>
          <a href="#features" className="text-sm hover:text-primary transition">
            Features
          </a>
          <Link href="/blog">
            <a
              className={`text-sm transition ${
                currentPage === "blog" || currentPage === "article"
                  ? "text-primary font-semibold"
                  : "hover:text-primary"
              }`}
            >
              Blog
            </a>
          </Link>
          <a href="#faq" className="text-sm hover:text-primary transition">
            FAQ
          </a>
          <Button variant="outline" size="sm">
            Join Discord
          </Button>
        </div>
      </div>
    </nav>
  );
}
