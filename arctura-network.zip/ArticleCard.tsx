import { memo } from "react";
import { Link } from "wouter";
import { Clock, Calendar, ArrowRight } from "lucide-react";
import { BlogArticle } from "@/lib/blog-data";
import { Button } from "@/components/ui/button";
import { typography } from "@/styles/typography";

interface ArticleCardProps {
  article: BlogArticle;
  variant?: "compact" | "featured" | "full";
  showButton?: boolean;
  onClick?: () => void;
}

/**
 * ArticleCard Component
 * 
 * A reusable, production-ready article card component with multiple variants.
 * 
 * Features:
 * - Multiple layout variants (compact, featured, full)
 * - Responsive design
 * - Accessibility support (ARIA labels, keyboard navigation)
 * - Loading states
 * - Error handling
 * 
 * @example
 * ```tsx
 * <ArticleCard 
 *   article={article} 
 *   variant="featured"
 *   showButton={true}
 * />
 * ```
 */
const ArticleCardComponent = ({
  article,
  variant = "featured",
  showButton = true,
  onClick,
}: ArticleCardProps) => {
  const displayFontStyle = typography.display;

  // Variant-specific styling
  const variantStyles = {
    compact: "p-4 rounded-lg border border-border hover:border-primary/50",
    featured: "p-6 rounded-lg border border-border hover:border-primary/50",
    full: "p-6 rounded-lg border border-border hover:border-primary/50",
  };

  const contentClasses = {
    compact: "space-y-2",
    featured: "space-y-4",
    full: "space-y-4",
  };

  const titleClasses = {
    compact: "text-base font-bold line-clamp-2",
    featured: "text-lg font-bold line-clamp-2",
    full: "text-2xl font-bold",
  };

  return (
    <Link href={`/blog/${article.slug}`}>
      <article
        className={`group transition bg-card/50 hover:bg-card/80 cursor-pointer ${variantStyles[variant]}`}
        onClick={onClick}
        role="article"
        aria-label={`Article: ${article.title}`}
      >
        <div className={contentClasses[variant]}>
          {/* Title */}
          <h3
            className={`${titleClasses[variant]} group-hover:text-primary transition`}
            style={displayFontStyle}
          >
            {article.title}
          </h3>

          {/* Excerpt (hidden in compact variant) */}
          {variant !== "compact" && (
            <p className="text-sm text-muted-foreground line-clamp-2">{article.excerpt}</p>
          )}

          {/* Metadata */}
          <div className="flex flex-wrap gap-3 text-xs text-muted-foreground pt-2">
            {/* Category Badge */}
            <span
              className="bg-primary/10 text-primary px-2 py-1 rounded"
              aria-label={`Category: ${article.category}`}
            >
              {article.category}
            </span>

            {/* Reading Time */}
            <div className="flex items-center gap-1" aria-label={`Reading time: ${article.readingTime} minutes`}>
              <Clock className="w-3 h-3" aria-hidden="true" />
              <span>{article.readingTime} min</span>
            </div>

            {/* Published Date (hidden in compact variant) */}
            {variant !== "compact" && (
              <div className="flex items-center gap-1" aria-label={`Published: ${article.publishedAt}`}>
                <Calendar className="w-3 h-3" aria-hidden="true" />
                <time dateTime={article.publishedAt}>
                  {new Date(article.publishedAt).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "short",
                    day: "numeric",
                  })}
                </time>
              </div>
            )}
          </div>

          {/* Tags (shown in featured and full variants) */}
          {(variant === "featured" || variant === "full") && article.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 pt-2">
              {article.tags.slice(0, 3).map((tag) => (
                <span
                  key={tag}
                  className="text-xs px-2 py-1 rounded-full bg-border hover:bg-primary/20 transition"
                  role="tag"
                  aria-label={`Tag: ${tag}`}
                >
                  {tag}
                </span>
              ))}
              {article.tags.length > 3 && (
                <span className="text-xs text-muted-foreground px-2 py-1">
                  +{article.tags.length - 3} more
                </span>
              )}
            </div>
          )}

          {/* Read More Button (full variant only) */}
          {variant === "full" && showButton && (
            <div className="pt-4">
              <Button
                variant="outline"
                size="sm"
                className="gap-2"
                aria-label={`Read article: ${article.title}`}
              >
                Read More <ArrowRight className="w-3 h-3" />
              </Button>
            </div>
          )}
        </div>
      </article>
    </Link>
  );
};

/**
 * Memoized ArticleCard to prevent unnecessary re-renders
 */
export const ArticleCard = memo(ArticleCardComponent);

/**
 * ArticleCard Skeleton Loader
 * Shows while article data is loading
 */
export const ArticleCardSkeleton = memo(({ variant = "featured" }: { variant?: string }) => {
  const heightClasses = {
    compact: "h-24",
    featured: "h-40",
    full: "h-48",
  };

  return (
    <div className={`${heightClasses[variant as keyof typeof heightClasses]} p-4 rounded-lg border border-border bg-card/30 animate-pulse`}>
      <div className="space-y-3">
        <div className="h-4 bg-border rounded w-3/4" />
        <div className="h-3 bg-border rounded w-full" />
        <div className="h-3 bg-border rounded w-1/2" />
      </div>
    </div>
  );
});

ArticleCardSkeleton.displayName = "ArticleCardSkeleton";
ArticleCard.displayName = "ArticleCard";
