export interface BlogArticle {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  publishedAt: string;
  updatedAt?: string;
  category: "Technical" | "Design" | "Sustainability" | "Research";
  tags: string[];
  readingTime: number;
  featured: boolean;
  slug: string;
  seoDescription: string;
}

export const blogArticles: BlogArticle[] = [
  {
    id: "1",
    title: "Understanding Mandate Chains: We Tried RBAC. It Didn't Work.",
    excerpt:
      "We tried to build agent networks using traditional role-based access control. It failed. Here's what we learned and how mandate chains solve the problem.",
    slug: "mandate-chains-cryptographic-delegation",
    author: "Arctura Research Team",
    publishedAt: "2026-05-01",
    category: "Technical",
    tags: ["Mandate Chains", "Cryptography", "Authority Delegation", "Agent Architecture"],
    readingTime: 12,
    featured: true,
    seoDescription:
      "We tried RBAC for agent networks. It didn't work. Here's how mandate chains provide cryptographically verifiable delegation with bounded scopes and resource budgets.",
    content: `# Understanding Mandate Chains: We Tried RBAC. It Didn't Work.

We tried to build agent networks using traditional role-based access control (RBAC). Agents needed to delegate authority to other agents, so we implemented static roles. It didn't work. The problem: agents need to delegate authority dynamically, and traditional RBAC assumes static roles. An agent might delegate authority to another agent for 1 hour, then revoke it. RBAC can't handle this.

Mandate chains solve this. A mandate chain is a cryptographic proof that Agent A gave Agent B permission to do something, and Agent B gave Agent C permission to do something else. You can trace the entire chain and see exactly who authorized what. The hard part we're still solving: what happens when an agent in the middle goes rogue? We have three approaches in testing: (1) revoke the entire chain, (2) revoke only downstream mandates, (3) require re-authorization at each step. Each has tradeoffs.

## The Problem: Authority Without Boundaries

Consider a scenario where you deploy an autonomous agent to manage your cloud infrastructure. The agent needs to:

- Provision new compute resources when demand spikes
- Optimize costs by consolidating workloads
- Scale down during off-peak hours
- Respond to security incidents

Without proper authority boundaries, the agent could theoretically:

- Provision unlimited resources, causing runaway costs
- Delete critical infrastructure
- Bypass security policies
- Operate outside your compliance requirements

We tried RBAC. It didn't work because agents need dynamic delegation. Mandate chains make authority itself verifiable and auditable.

## How Mandate Chains Work

A mandate chain is a cryptographically signed sequence of authority delegations. Each link in the chain specifies:

1. **Principal Identity**: The entity delegating authority (human or agent)
2. **Agent Identity**: The recipient of the delegation
3. **Capability Scope**: What actions the agent is authorized to perform
4. **Resource Budget**: Limits on compute, memory, storage, or financial resources
5. **Carbon Budget**: Maximum carbon emissions for the mandate period
6. **Escalation Triggers**: Conditions that require human approval
7. **Temporal Bounds**: When the mandate is valid
8. **Cryptographic Proof**: A signature binding all parameters together

Each mandate is anchored to the previous one, creating an immutable chain of authority. Every agent action can be traced back to the original human decision.

## Example: A Mandate Chain in Action

Alice, a DevOps engineer, wants to delegate infrastructure management to an autonomous agent:

**Mandate 0 (Root)**: Alice → Agent
- Capability: Provision EC2 instances (t3.medium max)
- Resource Budget: $500/month
- Carbon Budget: 50 kg CO₂e/month
- Escalation: Notify if >$400 spent
- Valid: 2026-05-01 to 2026-06-01

**Mandate 1 (Sub-delegation)**: Agent → Sub-Agent (for cost optimization)
- Capability: Modify instance types (within t3 family)
- Resource Budget: $100/month (sub-budget of parent)
- Carbon Budget: 10 kg CO₂e/month
- Valid: 2026-05-01 to 2026-05-31

When the sub-agent optimizes a workload, it emits a cryptographic proof that includes the action taken, the mandate chain authorizing the action, the resource impact, a timestamp, and a nonce. This proof is verifiable by anyone without requiring access to private keys.

## The Unsolved Problem: Mandate Revocation

The hard part we're still solving: what happens when an agent in the middle goes rogue? If Agent B starts behaving badly, can Alice revoke the mandate to Agent B? This cascades down to Agent C. We have three approaches in testing:

1. **Full Revocation**: Revoke the entire chain, including all downstream mandates. Simple but harsh.
2. **Selective Revocation**: Revoke only downstream mandates from the rogue agent. More granular but complex.
3. **Re-authorization**: Require re-authorization at each step. Most secure but slowest.

We're testing this with real grid operators in Denmark. Early data is promising, but we don't know yet which approach works best at scale.

## Why This Matters

Mandate chains enable carbon-aware scheduling by embedding carbon budgets directly into authority delegations. When an agent receives a mandate with a carbon budget, it can query real-time grid carbon intensity data, defer non-urgent tasks to low-carbon windows, and choose compute regions based on renewable energy availability.

---

**We're still figuring this out.** If you're building agent networks or decentralized systems, come compare notes.`,
  },
  {
    id: "2",
    title: "Resonance BFT: We Spent 18 Months Trying Yuma. It Didn't Work.",
    excerpt:
      "We spent 18 months trying to use Yuma Consensus for agent networks. Consensus took 8 seconds. We needed 2. Here's what we built instead.",
    slug: "resonance-bft-frequency-adaptive-consensus",
    author: "Arctura Research Team",
    publishedAt: "2026-04-28",
    category: "Technical",
    tags: ["Consensus", "Byzantine Fault Tolerance", "Agent Networks", "Protocol Design"],
    readingTime: 15,
    featured: true,
    seoDescription:
      "We tried Yuma Consensus for agent networks. It didn't work. Resonance BFT reaches finality in 2.3 seconds instead of 8.",
    content: `# Resonance BFT: We Spent 18 Months Trying Yuma. It Didn't Work.

We spent 18 months trying to use Yuma Consensus for agent networks. It didn't work. Yuma Consensus is brilliant for Bittensor validators. It assumes a small number of validators with aligned incentives. We tried using it for agent networks with thousands of validators and competing incentives. Consensus took 8 seconds. We needed 2.

The problem: Yuma waits for 2/3 of validators to respond. With thousands of validators, that's a lot of waiting. And if validators have financial incentives to collude, they will.

We built Resonance BFT to fix this. It reaches finality in 2.3 seconds because it doesn't wait for all validators to respond — it stops when it has enough. Early testnet data is solid. We're still stress-testing with 10,000+ agents.

## The Core Innovation: Mandate Attestation

Instead of ordering transactions, Resonance BFT attests to the validity of agent mandates. Here's the key difference:

**Traditional Consensus**: "What is the canonical order of transactions?"
**Resonance BFT**: "Is this mandate valid according to the authority chain?"

This shift enables several critical improvements:

1. **No Re-orgs**: Once a mandate is attested, it's final. There's no concept of chain reorganization.
2. **Deterministic Finality**: Finality is guaranteed after a fixed number of rounds, not probabilistic.
3. **Parallel Attestation**: Multiple mandates can be attested in parallel, increasing throughput.
4. **Frequency Adaptation**: The protocol adjusts consensus frequency based on network conditions.

## How Resonance BFT Works

Resonance BFT operates in rounds. Each round has four phases:

### Phase 1: Mandate Proposal

Agents propose mandates they want to execute. A mandate includes the agent's identity, the action being proposed, the authority chain proving delegation, and resource and carbon impact estimates.

### Phase 2: Validity Checking

Validators check if each mandate is valid:

- Is the authority chain cryptographically correct?
- Does the mandate respect resource budgets?
- Is the carbon impact within limits?
- Are there conflicts with other mandates?

Validators vote on validity. A mandate is considered valid if >2/3 of validators agree.

### Phase 3: Attestation

Once a mandate is deemed valid, validators create a cryptographic attestation. This attestation includes the mandate content, signatures from >2/3 of validators, a timestamp, and a reference to the previous attestation.

### Phase 4: Finality

Once an attestation is created, it's **final**. No validator can change their vote. The mandate is now part of the immutable Truth Ledger.

## Frequency Adaptation

Resonance BFT doesn't run at a fixed block time. Instead, it adapts based on network conditions:

- **High Activity**: When many mandates are proposed, the protocol runs faster rounds to keep up
- **Low Activity**: When few mandates are proposed, the protocol slows down to conserve resources
- **Network Congestion**: If validators are slow to respond, the protocol extends round times
- **Byzantine Behavior**: If validators are detected as Byzantine, the protocol increases safety margins

## The Tradeoff We're Still Testing

The tradeoff: you need a higher threshold of honest validators. We're testing what that threshold looks like at scale. Early data suggests 75% honest validators is sufficient. We don't know yet if this holds with 10,000+ agents or if validators will collude to drop below this threshold.

---

**We're still stress-testing this.** If you're building consensus mechanisms or agent networks, we want your feedback.`,
  },
  {
    id: "3",
    title: "Carbon-Aware Scheduling: 28% Energy Reduction (Early Data)",
    excerpt:
      "A renewable energy grid in Denmark reduced compute energy consumption by 28% using carbon-aware scheduling. We're validating this on mainnet.",
    slug: "carbon-aware-scheduling-energy-reduction",
    author: "Arctura Research Team",
    publishedAt: "2026-04-25",
    category: "Sustainability",
    tags: ["Carbon-Aware", "Energy Efficiency", "Sustainability", "Grid Integration"],
    readingTime: 10,
    featured: true,
    seoDescription:
      "Early testnet data: carbon-aware scheduling reduces compute energy consumption by 28%. We're validating with real grid operators.",
    content: `# Carbon-Aware Scheduling: 28% Energy Reduction (Early Data)

A renewable energy grid in Denmark is using agent networks to balance load across 50,000+ solar installations. The problem: agents were scheduling compute during peak hours when the grid was stressed. So we built carbon-aware scheduling: route compute to times when renewable energy is abundant.

On the Danish grid, this means deferring compute to 2–4 AM when wind energy is abundant. Early testnet data shows 28% reduction in energy consumption. We're validating this on mainnet with real grid operators.

## The Problem We Observed

Agents were scheduling compute based on cost optimization alone. They'd run workloads during peak hours to minimize latency. But peak hours often coincide with peak grid demand, which means the grid is relying on fossil fuels to meet demand.

The grid operator in Denmark asked: "Can your agents defer non-urgent compute to times when renewable energy is abundant?" We said yes. We built carbon-aware scheduling to do exactly that.

## How It Works

Carbon-aware scheduling looks at real-time grid data and asks: "When will renewable energy be abundant?" It then defers non-urgent compute to those times. On the Danish grid, this means deferring compute to 2–4 AM when wind energy is abundant.

The agent can:

1. Query real-time grid carbon intensity data
2. Defer non-urgent tasks to low-carbon windows
3. Choose compute regions based on renewable energy availability
4. Optimize for carbon efficiency, not just cost

## Early Results

Early testnet data on the Danish grid shows 28% reduction in energy consumption. We're validating this on mainnet with real grid operators.

## The Unsolved Problems

The hard part we're still solving:

1. **Compute That Can't Be Deferred**: What about workloads that need to run immediately? How do you handle compute that can't be deferred?
2. **Multiple Grids**: What happens when multiple grids have different renewable profiles? How do you optimize across geographically distributed grids?
3. **Prediction Accuracy**: Our carbon intensity predictions are based on historical data. What happens when the grid behaves unexpectedly?

We're testing this with grid operators in Denmark and California. Early data is promising, but we don't know yet how this scales globally.

---

**We're still figuring this out.** If you're running a grid or building agent networks, come compare notes.`,
  },
  {
    id: "4",
    title: "Trustworthy Agent Design: We Tried Without Verification. Agents Lied.",
    excerpt:
      "We tried to build agent networks without cryptographic verification. Agents lied about their work, and we had no way to prove it. Here's what we learned.",
    slug: "trustworthy-agent-design-verification",
    author: "Arctura Research Team",
    publishedAt: "2026-04-22",
    category: "Technical",
    tags: ["Agent Design", "Cryptography", "Verification", "Trust"],
    readingTime: 11,
    featured: false,
    seoDescription:
      "We tried to build agent networks without cryptographic verification. Agents lied. Now every decision is on-chain and auditable.",
    content: `# Trustworthy Agent Design: We Tried Without Verification. Agents Lied.

We tried to build agent networks without cryptographic verification. Agents lied about their work, and we had no way to prove it. Now every agent decision is recorded on-chain and cryptographically signed. You can audit any agent's decision history. We still don't have a good way to handle off-chain computation verification. That's next.

## The Problem We Discovered

Agents do most of their work off-chain: data processing, ML inference, API calls, etc. We can verify the result (did the agent achieve the goal?), but not the process (did the agent use the right algorithm?).

An agent could claim it optimized a workload using a sophisticated ML algorithm. In reality, it just guessed. We had no way to verify the claim.

## Our Solution: On-Chain Verification

Every agent decision is now recorded on-chain and cryptographically signed. You can audit any agent's decision history. This works for on-chain actions: transferring tokens, updating state, creating records.

## The Unsolved Problem: Off-Chain Verification

The hard part: off-chain computation. Agents do most of their work off-chain. We can verify the result, but not the process.

We're testing three approaches:

1. **Trusted Execution Environments (TEEs)**: Run agent code in a hardware-based TEE that produces a cryptographic proof of execution. Tradeoff: requires specialized hardware.

2. **Zero-Knowledge Proofs**: Generate a ZK proof that the agent executed the correct algorithm without revealing the algorithm or the data. Tradeoff: computationally expensive.

3. **Spot-Checking with Human Auditors**: Randomly select agent decisions and have humans audit them. Tradeoff: doesn't scale.

We're testing all three approaches on mainnet. Early data is mixed. TEEs are fast but require hardware support. ZK proofs are slow but work everywhere. Spot-checking is cheap but doesn't scale.

## Looking Forward

Trustworthy agent design is essential. We have on-chain verification working. We're still figuring out off-chain verification. If you're building agent networks or running audits, we want your feedback.

---

**We're still solving this.** Come compare notes.`,
  },
];

export function getFeaturedArticles(limit: number = 3): BlogArticle[] {
  return blogArticles.filter((article) => article.featured).slice(0, limit);
}

export function getArticleBySlug(slug: string): BlogArticle | undefined {
  return blogArticles.find((article) => article.slug === slug);
}

export function getArticlesByCategory(category: string): BlogArticle[] {
  return blogArticles.filter((article) => article.category === category);
}

export function getArticlesByTag(tag: string): BlogArticle[] {
  return blogArticles.filter((article) => article.tags.includes(tag));
}

export function searchArticles(query: string): BlogArticle[] {
  const lowerQuery = query.toLowerCase();
  return blogArticles.filter(
    (article) =>
      article.title.toLowerCase().includes(lowerQuery) ||
      article.excerpt.toLowerCase().includes(lowerQuery) ||
      article.content.toLowerCase().includes(lowerQuery) ||
      article.tags.some((tag) => tag.toLowerCase().includes(lowerQuery))
  );
}

export function getAllTags(): string[] {
  const tags = new Set<string>();
  blogArticles.forEach((article) => {
    article.tags.forEach((tag) => tags.add(tag));
  });
  return Array.from(tags).sort();
}

export function getAllCategories(): string[] {
  const categories = new Set<string>();
  blogArticles.forEach((article) => {
    categories.add(article.category);
  });
  return Array.from(categories).sort();
}

export function getRelatedArticles(articleId: string, limit: number = 3): BlogArticle[] {
  const article = blogArticles.find((a) => a.id === articleId);
  if (!article) return [];

  return blogArticles
    .filter(
      (a) =>
        a.id !== articleId &&
        (a.category === article.category || a.tags.some((tag) => article.tags.includes(tag)))
    )
    .slice(0, limit);
}
