import { useState, useMemo } from "react";
import { Link } from "wouter";
import { Search, Calendar, Clock, Tag } from "lucide-react";
import { blogArticles, BlogArticle } from "@/lib/blog-data";
import { Button } from "@/components/ui/button";

const displayFontStyle = { fontFamily: "'Syne', sans-serif" };

export default function Blog() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  // Get unique categories and tags
  const categories = Array.from(new Set(blogArticles.map((a) => a.category)));
  const allTags = Array.from(new Set(blogArticles.flatMap((a) => a.tags)));

  // Filter articles based on search and filters
  const filteredArticles = useMemo(() => {
    return blogArticles.filter((article) => {
      const matchesSearch =
        searchQuery === "" ||
        article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesCategory = !selectedCategory || article.category === selectedCategory;
      const matchesTag = !selectedTag || article.tags.includes(selectedTag);

      return matchesSearch && matchesCategory && matchesTag;
    });
  }, [searchQuery, selectedCategory, selectedTag]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <Link href="/">
            <a className="font-bold text-xl text-primary" style={displayFontStyle}>
              Arctura.network
            </a>
          </Link>
          <div className="flex items-center gap-6">
            <Link href="/">
              <a className="text-sm hover:text-primary transition">Home</a>
            </Link>
            <Link href="/blog">
              <a className="text-sm hover:text-primary transition">Blog</a>
            </Link>
            <Button variant="outline" size="sm">
              Join Discord
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-16 border-b border-border">
        <div className="container max-w-3xl">
          <h1 className="font-bold text-5xl mb-4" style={displayFontStyle}>
            Arctura Blog
          </h1>
          <p className="text-lg text-muted-foreground">
            Deep dives into mandate chains, Resonance BFT consensus, carbon-aware scheduling, and
            the future of autonomous agents.
          </p>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="py-8 border-b border-border bg-card/30">
        <div className="container max-w-4xl">
          {/* Search Bar */}
          <div className="mb-8">
            <div className="relative">
              <Search className="absolute left-4 top-3 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 rounded-lg bg-background border border-border focus:outline-none focus:ring-2 focus:ring-primary/50 transition"
              />
            </div>
          </div>

          {/* Category Filter */}
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-3">Categories</h3>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setSelectedCategory(null)}
                className={`px-4 py-2 rounded-lg text-sm transition ${
                  selectedCategory === null
                    ? "bg-primary text-primary-foreground"
                    : "bg-card border border-border hover:border-primary/50"
                }`}
              >
                All
              </button>
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-lg text-sm transition ${
                    selectedCategory === category
                      ? "bg-primary text-primary-foreground"
                      : "bg-card border border-border hover:border-primary/50"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Tag Filter */}
          <div>
            <h3 className="text-sm font-semibold text-muted-foreground mb-3">Tags</h3>
            <div className="flex flex-wrap gap-2">
              {allTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
                  className={`px-3 py-1 rounded-full text-xs transition ${
                    selectedTag === tag
                      ? "bg-primary text-primary-foreground"
                      : "bg-card border border-border hover:border-primary/50"
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Articles Grid */}
      <section className="py-16">
        <div className="container max-w-4xl">
          {filteredArticles.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">No articles found matching your filters.</p>
              <button
                onClick={() => {
                  setSearchQuery("");
                  setSelectedCategory(null);
                  setSelectedTag(null);
                }}
                className="text-primary hover:underline"
              >
                Clear filters
              </button>
            </div>
          ) : (
            <div className="space-y-8">
              {filteredArticles.map((article) => (
                <Link key={article.id} href={`/blog/${article.slug}`}>
                  <article
                    className="p-6 rounded-lg border border-border hover:border-primary/50 transition bg-card/50 hover:bg-card/80 cursor-pointer"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
                      <div className="flex-1">
                        <h2
                          className="font-bold text-2xl mb-2 hover:text-primary transition"
                          style={displayFontStyle}
                        >
                          {article.title}
                        </h2>
                      <p className="text-muted-foreground mb-4">{article.excerpt}</p>

                      {/* Metadata */}
                      <div className="flex flex-wrap gap-4 text-sm text-muted-foreground mb-4">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(article.publishedAt).toLocaleDateString("en-US", {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          })}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {article.readingTime} min read
                        </div>
                        <div className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                          {article.category}
                        </div>
                      </div>

                      {/* Tags */}
                      <div className="flex flex-wrap gap-2">
                        {article.tags.map((tag) => (
                          <button
                            key={tag}
                            onClick={() => setSelectedTag(tag)}
                            className="text-xs px-2 py-1 rounded-full bg-border hover:bg-primary/20 transition cursor-pointer"
                          >
                            {tag}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Read More Button */}
                    <div className="flex-shrink-0">
                      <Button variant="outline">Read More</Button>
                    </div>
                  </div>
                  </article>
                </Link>
              ))}
            </div>
          )}

          {/* Results Count */}
          <div className="mt-12 text-center text-sm text-muted-foreground">
            Showing {filteredArticles.length} of {blogArticles.length} articles
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border bg-card/30">
        <div className="container">
          <div className="flex flex-col sm:flex-row items-center justify-between">
            <div className="font-bold text-primary" style={displayFontStyle}>
              Arctura.network
            </div>
            <div className="flex gap-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-primary transition">
                Privacy
              </a>
              <a href="#" className="hover:text-primary transition">
                Terms
              </a>
              <a href="#" className="hover:text-primary transition">
                Contact
              </a>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-border text-center text-xs text-muted-foreground">
            <p>© 2026 Arctura Collective. Building the future of autonomous intelligence.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
