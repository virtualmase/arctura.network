/**
 * Centralized Typography Styles
 * 
 * This file contains all typography-related inline styles used throughout the application.
 * Using a single source of truth makes it easier to update fonts globally.
 */

export const typography = {
  /**
   * Display font: Syne
   * Used for headings, titles, and prominent text
   * Weight: 700 (bold)
   */
  display: {
    fontFamily: "'Syne', sans-serif",
  },

  /**
   * Monospace font: IBM Plex Mono
   * Used for code blocks, technical content, and data
   * Weight: 400 (regular)
   */
  mono: {
    fontFamily: "'IBM Plex Mono', monospace",
  },
} as const;

/**
 * Hook for accessing typography styles
 * Ensures consistency across components
 */
export const useTypography = () => typography;

/**
 * Preset combinations for common use cases
 */
export const typographyPresets = {
  // Large display heading
  h1: {
    ...typography.display,
    fontSize: "3.5rem",
    fontWeight: 700,
    lineHeight: 1.2,
  },

  // Medium display heading
  h2: {
    ...typography.display,
    fontSize: "2.25rem",
    fontWeight: 700,
    lineHeight: 1.3,
  },

  // Small display heading
  h3: {
    ...typography.display,
    fontSize: "1.875rem",
    fontWeight: 700,
    lineHeight: 1.4,
  },

  // Body text
  body: {
    fontSize: "1rem",
    fontWeight: 400,
    lineHeight: 1.6,
  },

  // Small text
  small: {
    fontSize: "0.875rem",
    fontWeight: 400,
    lineHeight: 1.5,
  },

  // Code text
  code: {
    ...typography.mono,
    fontSize: "0.875rem",
    fontWeight: 400,
  },
} as const;
