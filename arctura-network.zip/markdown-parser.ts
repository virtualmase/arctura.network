import { useMemo } from "react";

export interface ParsedMarkdown {
  sections: MarkdownSection[];
  headingCount: number;
  codeBlockCount: number;
}

export interface MarkdownSection {
  type: "heading1" | "heading2" | "heading3" | "paragraph" | "code" | "blockquote" | "list";
  content: string;
  level?: number;
}

export function parseMarkdown(content: string): ParsedMarkdown {
  const sections: MarkdownSection[] = [];
  let headingCount = 0;
  let codeBlockCount = 0;

  const paragraphs = content.split("\n\n");

  for (const paragraph of paragraphs) {
    if (paragraph.startsWith("# ")) {
      sections.push({
        type: "heading1",
        content: paragraph.slice(2),
        level: 1,
      });
      headingCount++;
    } else if (paragraph.startsWith("## ")) {
      sections.push({
        type: "heading2",
        content: paragraph.slice(3),
        level: 2,
      });
      headingCount++;
    } else if (paragraph.startsWith("### ")) {
      sections.push({
        type: "heading3",
        content: paragraph.slice(4),
        level: 3,
      });
      headingCount++;
    } else if (paragraph.startsWith("```")) {
      sections.push({
        type: "code",
        content: paragraph.slice(3, -3).trim(),
      });
      codeBlockCount++;
    } else if (paragraph.startsWith(">")) {
      sections.push({
        type: "blockquote",
        content: paragraph.slice(2),
      });
    } else if (paragraph.startsWith("- ")) {
      sections.push({
        type: "list",
        content: paragraph,
      });
    } else if (paragraph.trim()) {
      sections.push({
        type: "paragraph",
        content: paragraph,
      });
    }
  }

  return {
    sections,
    headingCount,
    codeBlockCount,
  };
}

export function useParsedMarkdown(content: string): ParsedMarkdown {
  return useMemo(() => parseMarkdown(content), [content]);
}

export function calculateReadingTime(content: string, wordsPerMinute: number = 200): number {
  const wordCount = content.split(/\s+/).length;
  const readingTime = Math.ceil(wordCount / wordsPerMinute);
  return Math.max(readingTime, 1);
}

export function extractPlainText(content: string): string {
  return content
    .replace(/^#+\s/gm, "")
    .replace(/```[\s\S]*?```/g, "")
    .replace(/\*\*(.+?)\*\*/g, "$1")
    .replace(/\*(.+?)\*/g, "$1")
    .replace(/\[(.+?)\]\(.+?\)/g, "$1")
    .replace(/^>\s/gm, "")
    .trim();
}

export function extractFirstParagraph(content: string, maxLength: number = 160): string {
  const plainText = extractPlainText(content);
  const firstParagraph = plainText.split("\n\n")[0];

  if (firstParagraph.length > maxLength) {
    return firstParagraph.substring(0, maxLength).trim() + "...";
  }

  return firstParagraph;
}

export function generateTableOfContents(
  content: string
): Array<{ level: number; text: string; id: string }> {
  const headings: Array<{ level: number; text: string; id: string }> = [];
  const headingRegex = /^(#{1,3})\s+(.+)$/gm;
  let match;

  while ((match = headingRegex.exec(content)) !== null) {
    const level = match[1].length;
    const text = match[2];
    const id = text
      .toLowerCase()
      .replace(/[^\w\s-]/g, "")
      .replace(/\s+/g, "-");

    headings.push({ level, text, id });
  }

  return headings;
}
