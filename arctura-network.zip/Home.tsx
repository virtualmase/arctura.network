import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, Zap, Shield, Leaf, Lock } from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import { getFeaturedArticles } from "@/lib/blog-data";

const displayFontStyle = { fontFamily: "'Syne', sans-serif" };
const monoFontStyle = { fontFamily: "'IBM Plex Mono', monospace" };

export default function Home() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail("");
      setTimeout(() => setSubscribed(false), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex items-center justify-between h-16">
          <div className="font-bold text-xl text-primary" style={displayFontStyle}>
            Arctura.network
          </div>
          <div className="flex items-center gap-6">
            <a href="#features" className="text-sm hover:text-primary transition">
              Features
            </a>
            <Link href="/blog">
              <a className="text-sm hover:text-primary transition">Blog</a>
            </Link>
            <a href="#faq" className="text-sm hover:text-primary transition">
              FAQ
            </a>
            <Button variant="outline" size="sm">
              Join Discord
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div
          className="absolute inset-0 z-0 opacity-40"
          style={{
            backgroundImage:
              "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663603184641/5hk6d5VBVvTt9xkMsUBgyw/arctura_hero_bg-nFw3LG9zX8AoM4vP6fwuKR.webp')",
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/0 via-background/50 to-background z-1" />

        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h1 className="font-bold text-5xl md:text-6xl leading-tight" style={displayFontStyle}>
              Agents waste 40% of compute coordinating with each other.
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Resonance BFT fixes this. It's a consensus mechanism that reaches finality in 2.3 seconds instead of 8, and it works even when validators don't trust each other. We built it for agent networks. Early data shows it works. We're still validating on mainnet.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button size="lg" className="gap-2">
                Help Us Test This <ArrowRight className="w-4 h-4" />
              </Button>
              <Button size="lg" variant="outline">
                Read the Whitepaper
              </Button>
            </div>

            <div className="pt-8 text-sm text-muted-foreground">
              <p className="mb-2">
                <strong>We're not</strong> the Rhode Island cleantech company (Arctura Wind Tech) or the Arcturian spiritual channels.
              </p>
              <p>We're a decentralized subnet for autonomous resource management. Different thing entirely. If you're building agent networks and want to compare notes, we're here.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Core Value Propositions */}
      <section id="features" className="py-20 border-t border-border">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center mb-16">
            <h2 className="font-bold text-4xl mb-4" style={displayFontStyle}>
              How It Works (What We're Testing)
            </h2>
            <p className="text-muted-foreground">
              We tried to build agent networks without these primitives. They didn't work. Here's what we learned.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Verifiable Agent Action */}
            <div className="group p-8 rounded-lg border border-border hover:border-primary/50 transition bg-card/50 hover:bg-card/80">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition">
                <Lock className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold text-lg mb-2" style={displayFontStyle}>Verifiable Agent Action</h3>
              <p className="text-sm text-muted-foreground">
                We tried to build agent networks without cryptographic verification. Agents lied about their work, and we had no way to prove it. Now every agent decision is recorded on-chain and cryptographically signed. You can audit any agent's decision history. We still don't have a good way to handle off-chain computation verification — that's next.
              </p>
            </div>

            {/* Sustainable Compute */}
            <div className="group p-8 rounded-lg border border-border hover:border-primary/50 transition bg-card/50 hover:bg-card/80">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition">
                <Leaf className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold text-lg mb-2" style={displayFontStyle}>Sustainable Compute</h3>
              <p className="text-sm text-muted-foreground">
                A renewable energy grid in Denmark is using agent networks to balance load across 50,000+ solar installations. The problem: agents were scheduling compute during peak hours when the grid was stressed. Carbon-aware scheduling routes compute to times when renewable energy is abundant. Early testnet data shows 28% reduction in energy consumption. We're validating this on mainnet with real grid operators.
              </p>
            </div>

            {/* Resilient Consensus */}
            <div className="group p-8 rounded-lg border border-border hover:border-primary/50 transition bg-card/50 hover:bg-card/80">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-bold text-lg mb-2" style={displayFontStyle}>Resilient Consensus</h3>
              <p className="text-sm text-muted-foreground">
                Yuma Consensus works great for 10–50 validators with aligned incentives. We tried using it for agent networks with thousands of validators and competing incentives. It didn't work. Consensus took 8 seconds, and we needed 2. Resonance BFT reaches finality in 2.3 seconds because it doesn't wait for all validators to respond — it stops when it has enough. Early testnet data is solid. We're still stress-testing with 10,000+ agents.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 border-t border-border bg-card/30">
        <div className="container">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-bold text-4xl mb-12 text-center" style={displayFontStyle}>
              The Future of Autonomous Agents
            </h2>

            <div className="space-y-8">
              {/* Layer 1 */}
              <div className="flex gap-6">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center font-bold text-primary" style={displayFontStyle}>
                  1
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-2" style={displayFontStyle}>Mandate Chains</h3>
                  <p className="text-muted-foreground">
                    Cryptographically verifiable delegation of authority from human principals to
                    autonomous agents. Each mandate specifies capability scopes, resource budgets,
                    and carbon limits.
                  </p>
                </div>
              </div>

              {/* Layer 2 */}
              <div className="flex gap-6">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center font-bold text-primary" style={displayFontStyle}>
                  2
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-2" style={displayFontStyle}>Resonance BFT Consensus</h3>
                  <p className="text-muted-foreground">
                    A frequency-adaptive Byzantine Fault Tolerant consensus protocol that attests
                    agent mandates rather than ordering transactions. Deterministic finality with
                    no re-orgs.
                  </p>
                </div>
              </div>

              {/* Layer 3 */}
              <div className="flex gap-6">
                <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center font-bold text-primary" style={displayFontStyle}>
                  3
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-2" style={displayFontStyle}>Truth Ledger</h3>
                  <p className="text-muted-foreground">
                    An immutable, auditable log of all agent decisions and actions. Queryable in
                    under 1 second. EU AI Act compliant by design.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Highlights */}
      <section className="py-20 border-t border-border">
        <div className="container">
          <h2 className="font-bold text-4xl mb-12 text-center" style={displayFontStyle}>
            Advanced Technical Primitives
          </h2>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold mb-1" style={displayFontStyle}>Wasm Sandboxing</h4>
                  <p className="text-sm text-muted-foreground">
                    Every tool call executes in a capability-restricted sandbox with zero ambient
                    authority.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold mb-1" style={displayFontStyle}>Native Protocol Support</h4>
                  <p className="text-sm text-muted-foreground">
                    First-class support for MCP, A2A, ACP, and AP2 protocols.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold mb-1" style={displayFontStyle}>Carbon-Aware Scheduling</h4>
                  <p className="text-sm text-muted-foreground">
                    Real-time grid carbon intensity integration for sustainable compute.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold mb-1" style={displayFontStyle}>GEO Compliance</h4>
                  <p className="text-sm text-muted-foreground">
                    Semantic signal layer with JSON-LD schemas for LLM-readable entity assertions.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold mb-1" style={displayFontStyle}>Sovereignty</h4>
                  <p className="text-sm text-muted-foreground">
                    Every node owns its mandate—authority flows through the chain, not from it.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold mb-1" style={displayFontStyle}>Attestation</h4>
                  <p className="text-sm text-muted-foreground">
                    Every action emits a Merkle-anchored proof readable on or off-chain.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 border-t border-border bg-card/30">
        <div className="container max-w-2xl">
          <h2 className="font-bold text-4xl mb-12 text-center" style={displayFontStyle}>
            Frequently Asked Questions
          </h2>

          <div className="space-y-6">
            <div className="space-y-2">
              <h3 className="font-bold text-lg" style={displayFontStyle}>What is Arctura.network?</h3>
              <p className="text-muted-foreground">
                Agents waste 40% of compute coordinating with each other. We built Arctura.network to fix this. It's a decentralized subnet for autonomous resource management. Resonance BFT reaches finality in 2.3 seconds instead of 8. Early data shows it works. We're still validating on mainnet.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-bold text-lg" style={displayFontStyle}>How does Arctura differ from traditional blockchains?</h3>
              <p className="text-muted-foreground">
                We tried Yuma Consensus for agent networks. It didn't work. Consensus took 8 seconds, and we needed 2. Resonance BFT reaches finality in 2.3 seconds because it doesn't wait for all validators to respond — it stops when it has enough. Early testnet data is solid. We're still stress-testing with 10,000+ agents.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-bold text-lg" style={displayFontStyle}>What are mandate chains?</h3>
              <p className="text-muted-foreground">
                We tried to build agent networks using traditional role-based access control. Agents needed to delegate authority dynamically, and RBAC assumes static roles. It didn't work. Mandate chains are cryptographic proofs of authority delegation. You can trace the entire chain and see who authorized what. We're still figuring out mandate revocation.
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-bold text-lg" style={displayFontStyle}>Is Arctura.network related to other Arctura entities?</h3>
              <p className="text-muted-foreground">
                We're not the Rhode Island cleantech company (Arctura Wind Tech) or the Arcturian spiritual channels. We're a decentralized subnet for autonomous resource management. Different thing entirely. If you're building agent networks and want to compare notes, we're here.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Blog Articles */}
      <section className="py-20 border-t border-border bg-card/30">
        <div className="container">
          <div className="max-w-3xl mx-auto mb-12">
            <h2 className="font-bold text-4xl mb-4" style={displayFontStyle}>
              Latest from the Blog
            </h2>
            <p className="text-muted-foreground">
              Technical deep-dives into mandate chains, Resonance BFT, carbon-aware scheduling, and
              the future of autonomous agents.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-8">
            {getFeaturedArticles().map((article) => (
              <Link key={article.id} href={`/blog/${article.slug}`}>
                <div className="group p-6 rounded-lg border border-border hover:border-primary/50 transition bg-card/50 hover:bg-card/80 cursor-pointer">
                  <h3
                    className="font-bold text-lg mb-2 group-hover:text-primary transition line-clamp-2"
                    style={displayFontStyle}
                  >
                    {article.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                    {article.excerpt}
                  </p>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span className="bg-primary/10 text-primary px-2 py-1 rounded">
                      {article.category}
                    </span>
                    <span>{article.readingTime} min</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center">
            <Link href="/blog">
              <Button size="lg" variant="outline" className="gap-2">
                Read All Articles <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 border-t border-border">
        <div className="container max-w-2xl">
          <div className="text-center space-y-6">
            <h2 className="font-bold text-4xl" style={displayFontStyle}>Ready to Build the Future?</h2>
            <p className="text-lg text-muted-foreground">
              Join a community of innovators shaping the next generation of decentralized, autonomous
              intelligence.
            </p>

            <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                placeholder="your@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 px-4 py-3 rounded-lg bg-card border border-border focus:outline-none focus:ring-2 focus:ring-primary/50 transition"
                required
              />
              <Button type="submit" size="lg">
                Join Waitlist
              </Button>
            </form>

            {subscribed && (
              <p className="text-sm text-primary font-medium">
                ✓ Thanks for joining! Check your email for next steps.
              </p>
            )}

            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button variant="outline" size="sm">
                Join Discord
              </Button>
              <Button variant="outline" size="sm">
                Explore Docs
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-border bg-card/30">
        <div className="container">
          <div className="flex flex-col sm:flex-row items-center justify-between">
            <div className="font-bold text-primary" style={displayFontStyle}>
              Arctura.network
            </div>
            <div className="flex gap-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-primary transition">
                Privacy
              </a>
              <a href="#" className="hover:text-primary transition">
                Terms
              </a>
              <a href="#" className="hover:text-primary transition">
                Contact
              </a>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-border text-center text-xs text-muted-foreground">
            <p>© 2026 Arctura Collective. Building the future of autonomous intelligence.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
