import { useEffect } from "react";

/**
 * SEO Configuration Interface
 */
export interface SEOConfig {
  /** Page title (displayed in browser tab and search results) */
  title: string;

  /** Meta description (displayed in search results) */
  description: string;

  /** Open Graph image URL (for social media sharing) */
  ogImage?: string;

  /** Canonical URL (to prevent duplicate content issues) */
  canonical?: string;

  /** Keywords for search engines */
  keywords?: string[];

  /** Author name */
  author?: string;

  /** Language code (default: en) */
  lang?: string;

  /** Twitter card type */
  twitterCard?: "summary" | "summary_large_image" | "app" | "player";
}

/**
 * Custom hook for managing SEO metadata
 * 
 * Usage:
 * ```tsx
 * useSEO({
 *   title: "Article Title | Arctura.network",
 *   description: "Article description for search results",
 *   ogImage: "https://example.com/image.png",
 * });
 * ```
 */
export function useSEO(config: SEOConfig) {
  useEffect(() => {
    // Update page title
    document.title = config.title;

    // Update or create meta description
    let descriptionMeta = document.querySelector('meta[name="description"]');
    if (!descriptionMeta) {
      descriptionMeta = document.createElement("meta");
      descriptionMeta.setAttribute("name", "description");
      document.head.appendChild(descriptionMeta);
    }
    descriptionMeta.setAttribute("content", config.description);

    // Update Open Graph tags
    if (config.ogImage) {
      let ogImage = document.querySelector('meta[property="og:image"]');
      if (!ogImage) {
        ogImage = document.createElement("meta");
        ogImage.setAttribute("property", "og:image");
        document.head.appendChild(ogImage);
      }
      ogImage.setAttribute("content", config.ogImage);
    }

    // Update canonical URL
    if (config.canonical) {
      let canonical = document.querySelector('link[rel="canonical"]');
      if (!canonical) {
        canonical = document.createElement("link");
        canonical.setAttribute("rel", "canonical");
        document.head.appendChild(canonical);
      }
      canonical.setAttribute("href", config.canonical);
    }

    // Update keywords
    if (config.keywords && config.keywords.length > 0) {
      let keywordsMeta = document.querySelector('meta[name="keywords"]');
      if (!keywordsMeta) {
        keywordsMeta = document.createElement("meta");
        keywordsMeta.setAttribute("name", "keywords");
        document.head.appendChild(keywordsMeta);
      }
      keywordsMeta.setAttribute("content", config.keywords.join(", "));
    }

    // Update author
    if (config.author) {
      let authorMeta = document.querySelector('meta[name="author"]');
      if (!authorMeta) {
        authorMeta = document.createElement("meta");
        authorMeta.setAttribute("name", "author");
        document.head.appendChild(authorMeta);
      }
      authorMeta.setAttribute("content", config.author);
    }

    // Update language
    const lang = config.lang || "en";
    document.documentElement.lang = lang;

    // Update Twitter card
    if (config.twitterCard) {
      let twitterCard = document.querySelector('meta[name="twitter:card"]');
      if (!twitterCard) {
        twitterCard = document.createElement("meta");
        twitterCard.setAttribute("name", "twitter:card");
        document.head.appendChild(twitterCard);
      }
      twitterCard.setAttribute("content", config.twitterCard);
    }
  }, [config]);
}

/**
 * Helper function to generate SEO config for blog articles
 */
export function createArticleSEO(article: {
  title: string;
  excerpt: string;
  author: string;
  publishedAt: string;
  seoDescription: string;
  slug: string;
}) {
  return {
    title: `${article.title} | Arctura.network Blog`,
    description: article.seoDescription,
    keywords: ["Arctura", "autonomous agents", "decentralized AI", "blockchain"],
    author: article.author,
    canonical: `https://arctura.network/blog/${article.slug}`,
    twitterCard: "summary_large_image" as const,
  };
}
